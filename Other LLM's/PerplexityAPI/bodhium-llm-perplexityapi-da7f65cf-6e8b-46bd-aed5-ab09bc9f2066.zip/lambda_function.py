import json
import urllib.request
import urllib.error
import datetime
import os
import boto3
import psycopg2
import uuid
import logging
from botocore.exceptions import ClientError

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def get_secret(secret_name=None, region_name=None):
    """
    Fetch API key or secret value from AWS Secrets Manager
    Secret name and region are from environment variables or parameters.
    Returns:
    - If plain string: returns as-is.
    - If JSON: returns dict.
    """
    if secret_name is None:
        secret_name = os.environ.get('secret_name', 'Bodhium-PerplexityAPI')
    if region_name is None:
        region_name = os.environ.get('secret_region', 'us-east-1')
        
    if not secret_name:
        raise Exception("secret_name environment variable is required.")
    if not region_name:
        raise Exception("secret_region environment variable is required.")

    logger.info(f"Fetching secret from {secret_name} in region {region_name}")
    
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )

    try:
        get_secret_value_response = client.get_secret_value(SecretId=secret_name)
        secret = get_secret_value_response['SecretString']
        try:
            # If the secret value is JSON, return as dict, else as string
            parsed = json.loads(secret)
            logger.info(f"Successfully retrieved secret as JSON from {secret_name}")
            return parsed
        except json.JSONDecodeError:
            logger.info(f"Successfully retrieved secret as string from {secret_name}")
            return secret
    except ClientError as e:
        logger.error(f"Secrets Manager fetch failed for {secret_name}: {str(e)}")
        raise Exception(f"Secrets Manager fetch failed: {str(e)}")
    except Exception as e:
        logger.error(f"Error loading secret from {secret_name}: {str(e)}")
        raise Exception(f"Error loading secret: {str(e)}")

def get_db_connection():
    """Get PostgreSQL connection using credentials from Secrets Manager"""
    try:
        # Get database credentials from Secrets Manager
        secret = get_secret(secret_name="dev/rds", region_name="us-east-1")
        
        # Connect to PostgreSQL
        conn = psycopg2.connect(
            host=secret['DB_HOST'],
            database=secret['DB_NAME'],
            user=secret['DB_USER'],
            password=secret['DB_PASSWORD'],
            port=secret['DB_PORT']
        )
        logger.info("Successfully connected to database")
        return conn
    except Exception as e:
        logger.error(f"Error connecting to database: {e}")
        raise

def create_llm_task(query_text, job_id=None, query_id=None):
    """Create a new LLM task in the database and return the task_id"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        task_id = str(uuid.uuid4())
        
        # Insert new task
        insert_query = """
        INSERT INTO llmtasks (task_id, job_id, query_id, llm_model_name, status, created_at)
        VALUES (%s, %s, %s, %s, %s, %s)
        """
        
        cursor.execute(insert_query, (
            task_id,
            job_id,
            query_id,
            "perplexity",
            "created",
            datetime.datetime.now(datetime.timezone.utc)
        ))
        
        conn.commit()
        cursor.close()
        conn.close()
        
        logger.info(f"Created new LLM task with ID: {task_id}")
        return task_id
        
    except Exception as e:
        logger.error(f"Error creating LLM task: {e}")
        raise

def update_task_status(task_id, status, error_message=None, s3_output_path=None, completed_at=None):
    """Update the status of an LLM task in the database"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        update_fields = ["status = %s"]
        params = [status]
        
        if error_message is not None:
            update_fields.append("error_message = %s")
            params.append(error_message)
            
        if s3_output_path is not None:
            update_fields.append("s3_output_path = %s")
            params.append(s3_output_path)
            
        if completed_at is not None:
            update_fields.append("completed_at = %s")
            params.append(completed_at)
            
        # Add task_id as the last parameter
        params.append(task_id)
        
        query = f"UPDATE llmtasks SET {', '.join(update_fields)} WHERE task_id = %s"
        
        cursor.execute(query, params)
        conn.commit()
        cursor.close()
        conn.close()
        
        logger.info(f"Updated task {task_id} status to {status}")
        return True
        
    except Exception as e:
        logger.error(f"Error updating task status: {e}")
        raise

def make_perplexity_api_call(user_query, api_key):
    url = "https://api.perplexity.ai/chat/completions"
    payload = {
        "model": "sonar-pro",
        "messages": [
            {"role": "user", "content": user_query}
        ]
    }

    logger.info(f"Making API call to Perplexity for query: {user_query[:50]}...")
    data = json.dumps(payload).encode('utf-8')
    req = urllib.request.Request(url, data=data)
    req.add_header('Authorization', f'Bearer {api_key}')
    req.add_header('Content-Type', 'application/json')

    try:
        with urllib.request.urlopen(req, timeout=30) as response:
            response_data = response.read().decode('utf-8')
            logger.info("Perplexity API call successful")
            return json.loads(response_data), response.status
    except urllib.error.HTTPError as e:
        error_response = e.read().decode('utf-8') if e.read() else str(e)
        logger.error(f"HTTP Error from Perplexity API: {e.code} - {error_response}")
        return {'error': error_response}, e.code
    except urllib.error.URLError as e:
        logger.error(f"URL Error connecting to Perplexity API: {str(e)}")
        return {'error': f'URL Error: {str(e)}'}, 500
    except Exception as e:
        logger.error(f"Unexpected error in Perplexity API call: {str(e)}")
        return {'error': f'Request failed: {str(e)}'}, 500

def extract_response_data(resp_json):
    main_content = ""
    related_questions = []
    
    try:
        main_content = resp_json["choices"][0]["message"]["content"]
    except (KeyError, IndexError) as e:
        logger.warning(f"Could not extract main answer: {e}")

    try:
        related = resp_json["choices"][0]["message"].get("related_questions", [])
        related_questions = related if related else []
    except (KeyError, IndexError) as e:
        logger.warning(f"Could not extract related questions: {e}")

    return main_content, related_questions

def save_to_s3(data, bucket_name, key):
    s3_client = boto3.client('s3')
    try:
        s3_client.put_object(
            Bucket=bucket_name,
            Key=key,
            Body=json.dumps(data, ensure_ascii=False, indent=2),
            ContentType='application/json'
        )
        logger.info(f"Successfully saved data to S3: s3://{bucket_name}/{key}")
        return True
    except Exception as e:
        logger.error(f"Failed to save to S3: {e}")
        return False

def lambda_handler(event, context):
    """
    Lambda handler for Perplexity API with RDS integration.
    Environment variables:
    - secret_name, secret_region, S3_BUCKET, S3_PATH
    
    Event parameters:
    - query: required - The query to send to Perplexity
    - job_id: optional - UUID of the scrape job
    - query_id: optional - ID of the query record
    - task_id: optional - If provided, use this task_id instead of creating a new one
    - save_to_s3: optional - Whether to save to S3 (default: True)
    - s3_key: optional - Custom S3 key
    """
    
    task_id = None
    
    try:
        # Extract parameters from event
        user_query = event.get('query')
        job_id = event.get('job_id')  # Optional
        query_id = event.get('query_id')  # Optional
        task_id = event.get('task_id')  # Optional - use if provided
        
        logger.info(f"Received event: {json.dumps(event)}")
        
        if not user_query:
            return {
                'statusCode': 400,
                'body': json.dumps({'error': 'Missing query parameter in event'})
            }

        # Create or use existing LLM task in database
        if not task_id:
            try:
                task_id = create_llm_task(user_query, job_id, query_id)
                logger.info(f"Created new task with ID: {task_id}")
            except Exception as e:
                logger.error(f"Failed to create LLM task: {e}")
                return {
                    'statusCode': 500,
                    'body': json.dumps({'error': f'Failed to create LLM task: {str(e)}'})
                }
        else:
            logger.info(f"Using provided task_id: {task_id}")
            # Update status to acknowledge receipt
            update_task_status(task_id, "task received")

        # Update task status to "processing"
        update_task_status(task_id, "processing")

        # Fetch Perplexity API secret
        try:
            secret_val = get_secret()
            
            # Try to get the API key from the secret
            if isinstance(secret_val, str):
                api_key = secret_val
            elif isinstance(secret_val, dict):
                # Try to get the key named 'Bodhium-PerplexityAPI' first
                api_key = secret_val.get('Bodhium-PerplexityAPI')
                
                # If not found, try the first value in the dict
                if not api_key:
                    api_key = next(iter(secret_val.values()), None)
            else:
                api_key = None
                
            logger.info("Successfully retrieved Perplexity API key")
        except Exception as e:
            error_msg = f"Could not fetch Perplexity API key: {str(e)}"
            logger.error(error_msg)
            update_task_status(task_id, "failed", error_message=error_msg)
            return {
                'statusCode': 500,
                'body': json.dumps({'error': error_msg})
            }

        if not api_key:
            error_msg = "Could not determine API key from secret."
            logger.error(error_msg)
            update_task_status(task_id, "failed", error_message=error_msg)
            return {
                'statusCode': 500,
                'body': json.dumps({'error': error_msg})
            }

        # Get S3 configuration
        s3_bucket = os.environ.get('S3_BUCKET', 'bodhium-dev')
        s3_path = os.environ.get('S3_PATH', 'perplexity/')
        if s3_path and not s3_path.endswith('/'):
            s3_path += '/'
            
        logger.info(f"Using S3 bucket: {s3_bucket}, path: {s3_path}")
        logger.info(f"Processing query: {user_query}")

        # Make API call to Perplexity
        resp_json, status_code = make_perplexity_api_call(user_query, api_key)

        if status_code == 200:
            # Extract response data
            main_content, related_questions = extract_response_data(resp_json)
            
            result = {
                'task_id': task_id,
                'query': user_query,
                'timestamp': datetime.datetime.now().isoformat(),
                'main_answer': main_content,
                'related_questions': related_questions,
                'full_response': resp_json
            }

            # Save to S3 if requested
            s3_output_path = None
            save_to_s3_flag = event.get('save_to_s3', True)
            
            if save_to_s3_flag and s3_bucket:
                s3_key = event.get('s3_key')
                if not s3_key:
                    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
                    filename = f"perplexity_output_{timestamp}_{task_id[:8]}.json"
                    s3_key = f"{s3_path}{filename}"
                else:
                    if s3_path and not s3_key.startswith(s3_path):
                        s3_key = f"{s3_path}{s3_key}"

                if save_to_s3(result, s3_bucket, s3_key):
                    s3_output_path = f"s3://{s3_bucket}/{s3_key}"
                    result['s3_location'] = s3_output_path
                    logger.info(f"Output saved to S3: {s3_output_path}")
                else:
                    result['s3_error'] = "Failed to save to S3"
                    logger.warning("Failed to save to S3")

            # Update task status to completed
            completed_at = datetime.datetime.now(datetime.timezone.utc)
            update_task_status(task_id, "completed", s3_output_path=s3_output_path, completed_at=completed_at)

            logger.info("Query processed successfully")
            logger.info(f"Main Answer: {main_content[:200]}...")
            logger.info(f"Related Questions: {related_questions}")

            return {
                'statusCode': 200,
                'body': json.dumps(result, ensure_ascii=False, indent=2)
            }
        else:
            error_msg = f'Perplexity API error: {status_code}'
            api_error = resp_json.get('error', 'Unknown error')
            full_error_msg = f"{error_msg} - {api_error}"
            
            logger.error(full_error_msg)
            update_task_status(task_id, "failed", error_message=full_error_msg)
            
            return {
                'statusCode': status_code,
                'body': json.dumps({
                    'error': error_msg,
                    'message': api_error,
                    'task_id': task_id
                })
            }

    except Exception as e:
        error_msg = f'Internal error: {str(e)}'
        logger.error(error_msg)
        
        if task_id:
            try:
                update_task_status(task_id, "failed", error_message=error_msg)
            except Exception as update_error:
                logger.error(f"Failed to update task status: {update_error}")
        
        return {
            'statusCode': 500,
            'body': json.dumps({
                'error': error_msg,
                'task_id': task_id
            })
        }
