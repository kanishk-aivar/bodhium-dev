import json
import requests
import os
import boto3
import psycopg2
from psycopg2.extras import RealDictCursor
from datetime import datetime
import logging
import time
import uuid
from botocore.exceptions import ClientError


# ─────────────────────────  LOGGING  ─────────────────────────
logger = logging.getLogger()
logger.setLevel(logging.INFO)


# ─────────────────────────  CUSTOM ERRORS  ─────────────────────────
class ScrapingDogError(Exception):
    pass


class S3SaveError(Exception):
    pass


class ConfigurationError(Exception):
    pass


class DatabaseError(Exception):
    pass


# ─────────────────────────  SECRETS  ─────────────────────────
def get_secret(secret_name=None, region_name=None) -> dict:
    """
    Fetch JSON secret from AWS Secrets Manager.
    """
    if secret_name is None:
        secret_name = os.environ.get("SECRET_NAME")
    if region_name is None:
        region_name = os.environ.get("SECRET_REGION")

    if not secret_name or not region_name:
        raise ConfigurationError(
            "SECRET_NAME and SECRET_REGION environment variables must be set!"
        )

    session = boto3.session.Session()
    client = session.client("secretsmanager", region_name=region_name)

    try:
        resp = client.get_secret_value(SecretId=secret_name)
        return json.loads(resp["SecretString"])
    except Exception as exc:
        logger.error(f"Secrets Manager error: {exc}")
        raise


# ─────────────────────────  RDS HELPERS  ─────────────────────────
def get_db_connection():
    """
    Open a PostgreSQL connection using credentials stored in Secrets Manager.
    Uses 'dev/rds' secret by default.
    """
    try:
        creds = get_secret(secret_name="dev/rds", region_name="us-east-1")
        return psycopg2.connect(
            host=creds["DB_HOST"],
            port=creds.get("DB_PORT", 5432),
            database=creds["DB_NAME"],
            user=creds["DB_USER"],
            password=creds["DB_PASSWORD"],
            cursor_factory=RealDictCursor,
            connect_timeout=10
        )
    except Exception as e:
        logger.error(f"Error connecting to database: {e}")
        raise DatabaseError(f"Database connection failed: {e}")


def validate_foreign_keys(job_id, query_id):
    """Validate that job_id and query_id exist in their respective tables"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Validate job_id
        valid_job_id = None
        if job_id:
            cursor.execute("SELECT job_id FROM scrapejobs WHERE job_id = %s", (job_id,))
            if cursor.fetchone():
                valid_job_id = job_id
                logger.info(f"Valid job_id found: {job_id}")
            else:
                logger.warning(f"job_id {job_id} not found in scrapejobs table")
        
        # Validate query_id
        valid_query_id = None
        if query_id:
            cursor.execute("SELECT query_id FROM queries WHERE query_id = %s", (query_id,))
            if cursor.fetchone():
                valid_query_id = query_id
                logger.info(f"Valid query_id found: {query_id}")
            else:
                logger.warning(f"query_id {query_id} not found in queries table")
        
        cursor.close()
        conn.close()
        
        return valid_job_id, valid_query_id
        
    except Exception as e:
        logger.error(f"Error validating foreign keys: {e}")
        return None, None


def create_llm_task(job_id, query_id, llm_model_name="google-ai-mode"):
    """Create initial LLM task record and return task_id"""
    try:
        # Validate foreign keys
        valid_job_id, valid_query_id = validate_foreign_keys(job_id, query_id)
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        task_id = str(uuid.uuid4())
        
        cursor.execute(
            """
            INSERT INTO llmtasks (
                task_id,
                job_id,
                query_id,
                llm_model_name,
                status,
                created_at
            ) VALUES (%s, %s, %s, %s, %s, %s)
            """,
            (
                task_id,
                valid_job_id,
                valid_query_id,
                llm_model_name,
                "created",
                datetime.utcnow()
            )
        )
        
        conn.commit()
        cursor.close()
        conn.close()
        
        logger.info(f"Created LLM task with task_id: {task_id}")
        return task_id
        
    except Exception as e:
        logger.error(f"Error creating LLM task: {e}")
        raise DatabaseError(f"Failed to create LLM task: {e}")


def update_task_status(task_id, status, s3_location=None, error_message=None):
    """Update LLM task status and completion details"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        update_fields = ["status = %s"]
        params = [status]
        
        if s3_location is not None:
            update_fields.append("s3_output_path = %s")
            params.append(s3_location)
            
        if error_message is not None:
            update_fields.append("error_message = %s")
            params.append(error_message)
            
        if status in ['completed', 'failed']:
            update_fields.append("completed_at = %s")
            params.append(datetime.utcnow())
            
        params.append(task_id)
        
        query = f"UPDATE llmtasks SET {', '.join(update_fields)} WHERE task_id = %s"
        
        cursor.execute(query, params)
        conn.commit()
        cursor.close()
        conn.close()
        
        logger.info(f"Updated task {task_id} status to {status}")
        
    except Exception as e:
        logger.error(f"Error updating task status: {e}")
        # Don't raise here to avoid breaking the main flow


def save_llm_task_to_db(
    *,
    task_id: str,
    job_id: str,
    query_id: int,
    s3_location: str | None,
    status: str,
    error_message: str | None = None,
    llm_model_name: str = "google-ai-mode",
) -> bool:
    """
    Update existing LLM task with final results
    """
    try:
        update_task_status(
            task_id=task_id,
            status=status,
            s3_location=s3_location,
            error_message=error_message
        )
        return True
    except Exception as e:
        logger.error(f"Failed to update LLM task: {e}")
        return False


# ─────────────────────────  VALIDATION & UTILS  ─────────────────────────
def validate_query(q: str | None) -> bool:
    return isinstance(q, str) and 0 < len(q.strip()) <= 1_000


def clean_filename(q: str) -> str:
    cleaned = "".join(c for c in q if c.isalnum() or c in (" ", "-", "_")).rstrip()
    return cleaned.replace(" ", "_")[:50]


def extract_from_event(event: dict) -> tuple[str | None, str | None, str | None]:
    """
    Returns (query, job_id, query_id) extracted from body or query params.
    """
    query = job_id = query_id = None

    if body := event.get("body"):
        try:
            payload = json.loads(body) if isinstance(body, str) else body
            query = payload.get("query")
            job_id = payload.get("job_id")
            query_id = payload.get("query_id")
        except json.JSONDecodeError as exc:
            raise ValueError(f"Invalid JSON body: {exc}") from exc
    if not query and (qs := event.get("queryStringParameters")):
        query = qs.get("query")
        job_id = qs.get("job_id")
        query_id = qs.get("query_id")

    return query, job_id, query_id


# ─────────────────────────  SCRAPINGDOG  ─────────────────────────
def call_scrapingdog_api(api_key: str, q: str, country: str = "in") -> dict:
    url = "https://api.scrapingdog.com/google/ai_mode"
    params = {"api_key": api_key, "query": q, "country": country}
    logger.info(f"Calling ScrapingDog: {url} with params={params}")

    for attempt in range(3):
        try:
            resp = requests.get(url, params=params, timeout=30)
            logger.info(f"ScrapingDog status={resp.status_code}")
            if resp.status_code == 200:
                return resp.json()
            if resp.status_code == 400 and "please try again" in resp.text.lower():
                time.sleep(5 * (attempt + 1))
                continue
            raise ScrapingDogError(
                f"ScrapingDog failure {resp.status_code}: {resp.text}"
            )
        except requests.exceptions.Timeout:
            logger.warning("ScrapingDog timeout, retrying...")
        except requests.exceptions.RequestException as exc:
            raise ScrapingDogError(f"ScrapingDog request error: {exc}") from exc

    raise ScrapingDogError("ScrapingDog exhausted retries")


# ─────────────────────────  S3  ─────────────────────────
def save_to_s3(data: dict, q: str, bucket: str, prefix: str = "", task_id: str = None) -> tuple[str, str]:
    try:
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        task_suffix = f"_{task_id[:8]}" if task_id else ""
        filename = f"{clean_filename(q)}_{ts}{task_suffix}.json"
        key = f"{prefix.strip('/')}/{filename}".lstrip("/")

        boto3.client("s3").put_object(
            Bucket=bucket,
            Key=key,
            Body=json.dumps(
                {
                    "task_id": task_id,
                    "query": q, 
                    "timestamp": datetime.now().isoformat(), 
                    "response": data
                },
                indent=2,
                ensure_ascii=False,
            ),
            ContentType="application/json",
        )
        s3_path = f"s3://{bucket}/{key}"
        logger.info(f"Saved result to {s3_path}")
        return s3_path, filename
    except ClientError as exc:
        raise S3SaveError(f"S3 error: {exc}") from exc


# ─────────────────────────  API RESPONSES  ─────────────────────────
def api_response(code: int, body: dict) -> dict:
    return {
        "statusCode": code,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": "Content-Type",
            "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
        },
        "body": json.dumps(body, indent=2),
    }


# ─────────────────────────  ENV VALIDATION  ─────────────────────────
def must_get_env(var: str) -> str:
    val = os.environ.get(var)
    if not val:
        raise ConfigurationError(f"Environment variable {var} is required")
    return val


# ─────────────────────────  LAMBDA HANDLER  ─────────────────────────
def lambda_handler(event, _context):
    logger.info(f"Incoming event: {json.dumps(event)}")

    # CORS pre-flight
    if event.get("httpMethod") == "OPTIONS":
        return api_response(200, {})

    task_id = None

    try:
        # ───── env & secret ─────
        bucket = must_get_env("S3_BUCKET")
        prefix = os.environ.get("S3_PATH", "")
        secret = get_secret()
        api_key = secret["SCRAPINGDOG_API_KEY"]

        # ───── request data ─────
        query, job_id, query_id_raw = extract_from_event(event)
        if not validate_query(query):
            return api_response(400, {"error": "Valid 'query' is required", "success": False})

        if not job_id or not query_id_raw:
            return api_response(
                400,
                {
                    "error": "'job_id' and 'query_id' must be supplied",
                    "success": False,
                },
            )
        try:
            query_id = int(query_id_raw)
        except ValueError:
            return api_response(
                400,
                {"error": "'query_id' must be an integer", "success": False},
            )

        # ───── Create LLM task ─────
        try:
            task_id = create_llm_task(job_id, query_id)
        except DatabaseError as exc:
            logger.error(f"Failed to create LLM task: {exc}")
            return api_response(500, {"error": str(exc), "success": False})

        # ───── Update status to processing ─────
        update_task_status(task_id, "processing")

        # ───── ScrapingDog ─────
        try:
            result = call_scrapingdog_api(api_key, query)
        except ScrapingDogError as exc:
            logger.error(exc)
            update_task_status(task_id, "failed", error_message=str(exc))
            return api_response(502, {"error": str(exc), "success": False, "task_id": task_id})

        # ───── S3 save ─────
        try:
            s3_path, fname = save_to_s3(result, query, bucket, prefix, task_id)
            s3_error = None
            status_db = "completed"
        except S3SaveError as exc:
            logger.error(exc)
            s3_path = None
            fname = None
            s3_error = str(exc)
            status_db = "failed"

        # ───── Update final status ─────
        save_llm_task_to_db(
            task_id=task_id,
            job_id=job_id,
            query_id=query_id,
            s3_location=s3_path,
            status=status_db,
            error_message=s3_error,
        )

        # ───── response ─────
        return api_response(
            200,
            {
                "success": True,
                "task_id": task_id,
                "job_id": job_id,
                "query_id": query_id,
                "data": result,
                "s3_saved": bool(s3_path),
                "s3_path": s3_path,
                "filename": fname,
                "s3_error": s3_error,
            },
        )

    except ConfigurationError as exc:
        logger.error(exc)
        if task_id:
            update_task_status(task_id, "failed", error_message=str(exc))
        return api_response(500, {"error": str(exc), "success": False, "task_id": task_id})
    except Exception as exc:
        logger.error(f"Unhandled error: {exc}")
        if task_id:
            update_task_status(task_id, "failed", error_message=f"Internal error: {str(exc)}")
        return api_response(500, {"error": "Internal server error", "success": False, "task_id": task_id})
