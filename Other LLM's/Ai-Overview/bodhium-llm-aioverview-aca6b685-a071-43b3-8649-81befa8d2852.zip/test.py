# import json
# import datetime
# import os
# import boto3
# import logging
# import re
# from serpapi import GoogleSearch
# from botocore.exceptions import ClientError

# # Configure logging
# logger = logging.getLogger()
# logger.setLevel(logging.INFO)

# def get_secret():
#     """
#     Fetch secrets from AWS Secrets Manager.
#     Expected: secret contains a key "SERPAPI_API_KEY"
#     """
#     secret_name = os.environ.get("secret_name")
#     region_name = os.environ.get("secret_region")  

#     session = boto3.session.Session()
#     client = session.client(
#         service_name='secretsmanager',
#         region_name=region_name
#     )

#     try:
#         get_secret_value_response = client.get_secret_value(SecretId=secret_name)
#     except ClientError as e:
#         logger.error(f"Secrets Manager fetch failed: {str(e)}")
#         raise e

#     secret = get_secret_value_response['SecretString']
#     return json.loads(secret)

# def lambda_handler(event, context):
#     logger.info("Lambda function invoked")

#     # Fetch SerpAPI API key from Secrets Manager
#     try:
#         secret = get_secret()
#         api_key = secret["SERPAPI_API_KEY"]
#     except Exception as e:
#         logger.error(f"Error fetching SERPAPI_API_KEY from Secrets Manager: {str(e)}")
#         return {
#             'statusCode': 500,
#             'body': json.dumps({'error': 'Could not retrieve SERPAPI_API_KEY from Secrets Manager'})
#         }

#     s3_bucket = os.environ.get("S3_BUCKET")
#     s3_path = os.environ.get("S3_PATH")

#     # Get the query from the event
#     if 'body' in event:
#         try:
#             body = json.loads(event['body'])
#             user_query = body.get('query', '')
#             logger.info(f"Received query through API Gateway: {user_query}")
#         except Exception as e:
#             logger.error(f"Error parsing request body: {str(e)}")
#             return {
#                 'statusCode': 400,
#                 'body': json.dumps({'error': 'Invalid JSON in request body'})
#             }
#     else:
#         user_query = event.get('query', '')
#         logger.info(f"Received query through direct invocation: {user_query}")

#     if not user_query:
#         logger.warning("No query provided in the request")
#         return {
#             'statusCode': 400,
#             'body': json.dumps({'error': 'No query provided'})
#         }

#     # Extract data
#     logger.info(f"Extracting data for query: {user_query}")
#     result = extract_data(user_query, api_key)

#     if not result:
#         logger.warning(f"No data available for query: {user_query}")
#         return {
#             'statusCode': 404,
#             'body': json.dumps({
#                 'error': 'No data available',
#                 'message': 'No data returned for this query.'
#             })
#         }

#     formatted_result = [result]

#     # Save result to S3
#     try:
#         save_to_s3(formatted_result, user_query, s3_bucket, s3_path)
#         logger.info(f"Successfully saved data to S3 for query: {user_query}")
#     except Exception as e:
#         logger.error(f"Error saving to S3: {str(e)}")
#         # Continue execution even if S3 save fails

#     # Return result
#     return {
#         'statusCode': 200,
#         'body': json.dumps(formatted_result, ensure_ascii=False)
#     }

# def extract_data(query, api_key):
#     params = {
#         "engine": "google",
#         "q": query,
#         "api_key": api_key,
#         "hl": "en",
#         "gl": "us"
#     }

#     try:
#         logger.info(f"Sending request to SerpAPI for query: {query}")
#         search = GoogleSearch(params)
#         results = search.get_dict()

#         full_result = {
#             "searchQuery": query,
#             "extractedAt": datetime.datetime.now().isoformat(),
#             "full_serp": results,
#             "ai_overview": results.get('ai_overview')
#         }

#         logger.info(f"Successfully extracted data for query: {query}")
#         return full_result

#     except Exception as e:
#         logger.error(f"Error extracting data: {str(e)}")
#         return {
#             "error": str(e),
#             "searchQuery": query,
#             "extractedAt": datetime.datetime.now().isoformat(),
#             "full_serp": {},
#             "ai_overview": None
#         }

# def save_to_s3(result, query, bucket_name, s3_path):
#     s3_client = boto3.client('s3')

#     sanitized_query = re.sub(r'[^a-zA-Z0-9\s]', '', query).lower()
#     sanitized_query = sanitized_query.replace(' ', '_')

#     if len(sanitized_query) > 50:
#         words = sanitized_query.split('_')
#         if len(words) > 3:
#             sanitized_query = '_'.join(words[:3])

#     s3_key = f"{s3_path}/{sanitized_query}.json"

#     try:
#         result_json = json.dumps(result, ensure_ascii=False, indent=2)
#         s3_client.put_object(
#             Bucket=bucket_name,
#             Key=s3_key,
#             Body=result_json,
#             ContentType='application/json'
#         )
#         logger.info(f"Saved result to s3://{bucket_name}/{s3_key}")
#     except Exception as e:
#         logger.error(f"Error saving to S3: {str(e)}")
#         raise
