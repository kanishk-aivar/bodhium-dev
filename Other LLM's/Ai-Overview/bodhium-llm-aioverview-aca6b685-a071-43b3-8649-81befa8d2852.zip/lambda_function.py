import json
import datetime
import os
import boto3
import logging
import re
import psycopg2
import uuid
from serpapi import GoogleSearch
from botocore.exceptions import ClientError

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def get_secret(secret_name=None):
    """
    Fetch secrets from AWS Secrets Manager.
    """
    if secret_name is None:
        secret_name = os.environ.get("RDS_SECRET_NAME", "dev/rds")
        
    region_name = os.environ.get("secret_region", "us-east-1")

    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )

    try:
        get_secret_value_response = client.get_secret_value(SecretId=secret_name)
        secret = get_secret_value_response['SecretString']
        return json.loads(secret)
    except ClientError as e:
        logger.error(f"Secrets Manager fetch failed: {str(e)}")
        raise e

def get_db_connection():
    """Get PostgreSQL connection using credentials from Secrets Manager"""
    try:
        # Get database credentials from Secrets Manager
        secret = get_secret(os.environ.get("RDS_SECRET_NAME", "dev/rds"))
        
        # Connect to PostgreSQL
        conn = psycopg2.connect(
            host=secret['DB_HOST'],
            database=secret['DB_NAME'],
            user=secret['DB_USER'],
            password=secret['DB_PASSWORD'],
            port=secret['DB_PORT']
        )
        return conn
    except Exception as e:
        logger.error(f"Error connecting to database: {e}")
        raise

def create_llm_task(job_id, query_id, llm_model_name="google-ai-overview"):
    """Create initial LLM task record and return task_id"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        task_id = str(uuid.uuid4())
        
        cursor.execute(
            """
            INSERT INTO llmtasks (
                task_id,
                job_id,
                query_id,
                llm_model_name,
                status,
                created_at
            ) VALUES (%s, %s, %s, %s, %s, %s)
            """,
            (
                task_id,
                job_id,
                query_id,
                llm_model_name,
                "created",
                datetime.datetime.now(datetime.timezone.utc)
            )
        )
        
        conn.commit()
        cursor.close()
        conn.close()
        
        logger.info(f"Created LLM task with task_id: {task_id}")
        return task_id
        
    except Exception as e:
        logger.error(f"Error creating LLM task: {e}")
        raise


def update_task_status(task_id, status, error_message=None, s3_output_path=None, completed_at=None):
    """Update the status of an LLM task in the database"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        update_fields = ["status = %s"]
        params = [status]
        
        if error_message is not None:
            update_fields.append("error_message = %s")
            params.append(error_message)
            
        if s3_output_path is not None:
            update_fields.append("s3_output_path = %s")
            params.append(s3_output_path)
            
        if completed_at is not None:
            update_fields.append("completed_at = %s")
            params.append(completed_at)
            
        # Add task_id as the last parameter
        params.append(task_id)
        
        query = f"UPDATE llmtasks SET {', '.join(update_fields)} WHERE task_id = %s"
        
        cursor.execute(query, params)
        conn.commit()
        cursor.close()
        conn.close()
        
        logger.info(f"Updated task {task_id} status to {status}")
    except Exception as e:
        logger.error(f"Error updating task status: {e}")
        raise

def lambda_handler(event, context):
    logger.info("Lambda function invoked")
    logger.info(f"Received event: {json.dumps(event)}")

    # Extract job_id and query_id from the event
    job_id = event.get('job_id')
    query_id = event.get('query_id')
    
    if not job_id or not query_id:
        logger.error("No job_id or query_id provided in the event")
        return {
            'statusCode': 400,
            'body': json.dumps({'error': 'job_id and query_id are required'})
        }

    # Create LLM task
    try:
        task_id = create_llm_task(job_id, query_id, "google-ai-overview")
        logger.info(f"Created task with ID: {task_id}")
    except Exception as e:
        logger.error(f"Failed to create LLM task: {e}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': f'Failed to create LLM task: {str(e)}'})
        }

    # Update task status to "task received"
    update_task_status(task_id, "task received")

    # Fetch SerpAPI API key from Secrets Manager
    try:
        # Use the correct secret name from environment variables
        serpapi_secret_name = os.environ.get("secret_name", "Bodhium-SerpAPI")
        logger.info(f"Fetching SerpAPI key from secret: {serpapi_secret_name}")
        
        serpapi_secret = get_secret(serpapi_secret_name)
        api_key = serpapi_secret["SERPAPI_API_KEY"]
        logger.info("Successfully retrieved SERPAPI_API_KEY")
    except Exception as e:
        logger.error(f"Error fetching SERPAPI_API_KEY from Secrets Manager: {str(e)}")
        update_task_status(task_id, "failed", error_message=f"Could not retrieve SERPAPI_API_KEY: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': 'Could not retrieve SERPAPI_API_KEY from Secrets Manager'})
        }

    # Get S3 configuration from environment variables
    s3_bucket = os.environ.get("S3_BUCKET", "bodhium-dev")
    s3_path = os.environ.get("S3_PATH", "aioverview/")
    logger.info(f"Using S3 bucket: {s3_bucket}, path: {s3_path}")

    # Get the query from the event
    if 'body' in event:
        try:
            body = json.loads(event['body'])
            user_query = body.get('query', '')
            logger.info(f"Received query through API Gateway: {user_query}")
        except Exception as e:
            logger.error(f"Error parsing request body: {str(e)}")
            update_task_status(task_id, "failed", error_message=f"Invalid JSON in request body: {str(e)}")
            return {
                'statusCode': 400,
                'body': json.dumps({'error': 'Invalid JSON in request body'})
            }
    else:
        user_query = event.get('query', '')
        logger.info(f"Received query through direct invocation: {user_query}")

    if not user_query:
        logger.warning("No query provided in the request")
        update_task_status(task_id, "failed", error_message="No query provided")
        return {
            'statusCode': 400,
            'body': json.dumps({'error': 'No query provided'})
        }

    # Update task status to "llm task started"
    update_task_status(task_id, "llm task started")

    # Extract data
    logger.info(f"Extracting data for query: {user_query}")
    try:
        # Update task status to "running"
        update_task_status(task_id, "running")
        
        result = extract_data(user_query, api_key)

        if not result:
            logger.warning(f"No data available for query: {user_query}")
            update_task_status(task_id, "failed", error_message="No data returned for this query")
            return {
                'statusCode': 404,
                'body': json.dumps({
                    'error': 'No data available',
                    'message': 'No data returned for this query.'
                })
            }

        formatted_result = [result]

        # Save result to S3
        s3_output_path = None
        try:
            s3_output_path = save_to_s3(formatted_result, user_query, s3_bucket, s3_path)
            logger.info(f"Successfully saved data to S3 for query: {user_query}")
        except Exception as e:
            logger.error(f"Error saving to S3: {str(e)}")
            # Continue execution even if S3 save fails

        # Update task status to "completed" with S3 path
        now = datetime.datetime.now(datetime.timezone.utc)
        update_task_status(task_id, "completed", s3_output_path=s3_output_path, completed_at=now)

        # Return result
        return {
            'statusCode': 200,
            'body': json.dumps({
                'success': True,
                'task_id': task_id,
                'job_id': job_id,
                'query_id': query_id,
                'data': formatted_result,
                's3_saved': bool(s3_output_path),
                's3_path': s3_output_path
            }, ensure_ascii=False)
        }
    except Exception as e:
        logger.error(f"Error processing query: {str(e)}")
        update_task_status(task_id, "failed", error_message=str(e))
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }

def extract_data(query, api_key):
    params = {
        "engine": "google",
        "q": query,
        "api_key": api_key,
        "hl": "en",
        "gl": "us"
    }

    try:
        logger.info(f"Sending request to SerpAPI for query: {query}")
        search = GoogleSearch(params)
        results = search.get_dict()

        full_result = {
            "searchQuery": query,
            "extractedAt": datetime.datetime.now().isoformat(),
            "full_serp": results,
            "ai_overview": results.get('ai_overview')
        }

        logger.info(f"Successfully extracted data for query: {query}")
        return full_result

    except Exception as e:
        logger.error(f"Error extracting data: {str(e)}")
        return {
            "error": str(e),
            "searchQuery": query,
            "extractedAt": datetime.datetime.now().isoformat(),
            "full_serp": {},
            "ai_overview": None
        }

def save_to_s3(result, query, bucket_name, s3_path):
    s3_client = boto3.client('s3')

    sanitized_query = re.sub(r'[^a-zA-Z0-9\s]', '', query).lower()
    sanitized_query = sanitized_query.replace(' ', '_')

    if len(sanitized_query) > 50:
        words = sanitized_query.split('_')
        if len(words) > 3:
            sanitized_query = '_'.join(words[:3])

    s3_key = f"{s3_path}/{sanitized_query}_{str(uuid.uuid4())[:8]}.json"

    try:
        result_json = json.dumps(result, ensure_ascii=False, indent=2)
        s3_client.put_object(
            Bucket=bucket_name,
            Key=s3_key,
            Body=result_json,
            ContentType='application/json'
        )
        logger.info(f"Saved result to s3://{bucket_name}/{s3_key}")
        return f"s3://{bucket_name}/{s3_key}"
    except Exception as e:
        logger.error(f"Error saving to S3: {str(e)}")
        raise